-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 03 déc. 2020 à 08:04
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `archive`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom_client` text NOT NULL,
  `nif` text NOT NULL,
  `plaque` text NOT NULL,
  `manifest` text NOT NULL,
  `ter` text NOT NULL,
  `t` text NOT NULL,
  `declaration` text NOT NULL,
  `liquidation` text NOT NULL,
  `quittance` text NOT NULL,
  `sortie` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom_client`, `nif`, `plaque`, `manifest`, `ter`, `t`, `declaration`, `liquidation`, `quittance`, `sortie`) VALUES
(1, 'fdsgsag1335', 'rtjtjtjj', '', '', '', '', '', '', '', ''),
(2, '', '', '', '', '', '', '', '', '', ''),
(3, '1', '2', '3', '4', '5', '', '', '', '', ''),
(4, '', '', '', '', '', '', '', '', '', ''),
(5, '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'),
(6, 'nazem', 'gigguygiyyyu', 'y89y89y89y9y98y', 'y089y98y89y87y78y', 'u89u89u89u89u', 'jijiojpiojiojj', 'hjbhbhkbhkbh', 'ojpojpojpoijiopjiojio', 'uijiojoipjoijio', 'uiojijipopjoijioj'),
(7, 'emma', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `doc`
--

CREATE TABLE `doc` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `license_number` text NOT NULL,
  `holder` text NOT NULL,
  `issue_date` text NOT NULL,
  `created_at` text NOT NULL,
  `expire_dat` text NOT NULL,
  `id_client` int(11) NOT NULL,
  `upload_file` text NOT NULL,
  `departement` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `doc`
--

INSERT INTO `doc` (`id`, `title`, `license_number`, `holder`, `issue_date`, `created_at`, `expire_dat`, `id_client`, `upload_file`, `departement`) VALUES
(1, ' d ', 'BWBWB', 'BWBBGB', 'GRBWRBRB', 'RGBRBRB', 'BWBWRB', 1, 'uploads/1605857654-996-petty cash voucher.pdf', ''),
(2, ' d ', 'BWBWB', 'BWBBGB', 'GRBWRBRB', 'RGBRBRB', 'BWBWRB', 1, 'uploads/1605857807-723-REMINDER.txt', ''),
(3, 'knfnsdjn', 'fjngjkfngj', 'fngngjfnj', '19/11/2020', '20/10/2020', '22/11/2020', 1, 'uploads/1605922871-124-final draw.pdf', ''),
(4, 'urtftft', 'BWBWB', 'emma', '19/11/2020', '20/10/2020', '22/11/2020', 1, 'uploads/1605928818-559-echeancier (2).docx', ''),
(5, 'gouv', 'fjngjkfngj', 'emma', '19/11/2020', '2020-12-01', '22/11/2020', 1, 'uploads/1605928901-177-final draw.pdf', ''),
(6, 'gouv', 'fjngjkfngj', 'david', '19/11/2020', '20/10/2020', '22/11/2020', 6, 'uploads/1605929083-407-echeancier (2).docx', ''),
(7, 'bdgfbnb', 'ngndfgn', 'dfndn', '2020-11-23', '2020-11-12', '2020-10-29', 1, 'vide', 'on'),
(8, 'bdgfbnb', 'ngndfgn', 'dfndn', '2020-11-23', '2020-11-12', '2020-10-29', 1, 'vide', 'on'),
(9, 'AFGG', 'GASG', 'GASGAG', '2020-11-05', '2020-10-29', '2020-11-20', 1, 'vide', 'on'),
(10, 'gagag', 'gagfdg', 'gfgfdg', '2020-11-06', '2020-11-14', '2020-11-12', 1, 'uploads/index.html', 'on'),
(11, 'AFA', 'ASFAf', 'asfa', '2020-11-13', '2020-11-11', '2020-11-12', 1, 'uploads/index.html', 'on'),
(12, 'f', 'DFDF', 'DfF', '2020-11-19', '2020-11-04', '2020-11-12', 1, 'uploads/3076508b8539a9783297054b57bd770c6c3818d0.html', 'on'),
(13, 'd', 'AFf', 'AFF', '2020-11-20', '2020-11-14', '2020-11-05', 1, 'uploads/9b70c97969a9eff8c21e69a1d08cf310d5da9915.html', 'on'),
(14, 'vvvvv', '2egweg', 'egwegweg', '2020-11-13', '2020-11-13', '2020-11-14', 1, 'uploads/05448167977267e47ca1d30dfb71d662a8f955be.html', 'imports'),
(15, 'vvvvv', '2egweg', 'egwegweg', '2020-11-13', '2020-11-13', '2020-11-14', 1, 'uploads/2d55164095ccd2180322cbe60c909bce52598a60.html', 'imports'),
(16, 'vvvv', '2egweg', 'egwegweg', '2020-11-13', '2020-11-13', '2020-11-14', 1, 'uploads/1c5f7932608828a99841f6c93f282312c7f10f94.html', 'imports'),
(17, 'vvvv ttttt', '2egweg', 'egwegweg', '2020-11-13', '2020-12-01', '2020-11-14', 1, 'uploads/830760f89933d9cbed433a436e9d1055d89ae416.html', 'imports'),
(18, 'nazem', '12345677890', 'mbatanguli emmanuel', '2020-12-01', '2020-12-01', '2020-12-03', 1, 'uploads/1590a8290803760050a2aa5ff91ac637c9fdbaef.txt', 'exports');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `username`, `password`) VALUES
(1, 'dieu donnee', 'king', '1234');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `doc`
--
ALTER TABLE `doc`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `doc`
--
ALTER TABLE `doc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
