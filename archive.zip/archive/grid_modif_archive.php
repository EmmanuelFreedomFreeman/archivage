
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
            FICHE DE MODIFICATION D'ARCHIVE
            </div>
            <div class="card-body">
              <?php
               

                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                $client = $get_class->Select_Clients($_GET['id']);
                $get_all_doc = $get_class->Select_All_Doc();
                $get_a_doc = $get_class->Select_All_DocByIdDoc($_GET['doc']);
              ?>


<div class="modal-body">
            <img src="client.png" style="float:right;width:20%;"/>
              <h4>NOM DU CLIENT : <?php echo $client[0]['nom_client'];?></h4>
              <h4>NIF DU CLIENT : <?php echo $client[0]['nif'];?></h4>
              <h4>NUMERO DE PLAQUE : <?php echo $client[0]['plaque'];?></h4>
              <h4>MANIFEST : <?php echo $client[0]['manifest'];?></h4>
              
            </div>

<div id='e'></div>
            <form method='post' action='#e' enctype="multipart/form-data">
			  <div class="col-md-5" style="float: left;">
				  	<div class="form-group">
					    <label for="inputsm">TITRE DU COCUMENT</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='title' value='<?php echo $get_a_doc[0]['title'];?>' >
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">NUMERO DE LICENSE</label>
					    <input class="form-control" id="inputdefault" type="text" name='license_number' value='<?php echo $get_a_doc[0]['license_number'];?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">NOM DU TITULAIRE</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='holder' value='<?php echo $get_a_doc[0]['holder'];?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputdefault">DATE D'EMISSION</label>
					    <input class="form-control" id="inputdefault" type="date" name='issue_date' value='<?php echo $get_a_doc[0]['issue_date'];?>'>
				  	</div>
				  
			  </div>

			  <div class="col-md-5" style="float: right;">
                    <div class="form-group">
					    <label for="inputlg">DATE D'ARCHIVAGE DU DOSSIER</label>
					    <input class="form-control input-lg" id="inputlg" type="date" name='created_at' value='<?php echo $get_a_doc[0]['created_at'];?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputsm">DATE D'EXPIRATION</label>
					    <input class="form-control input-sm" id="inputsm" type="date" name='expire_dat' value='<?php echo $get_a_doc[0]['expire_dat'];?>'>
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">TELEVERSER UN FICHIER :</label>
					    <input class="form-control" id="inputdefault" type="file" name="files" >
				  	</div>
            <div class="form-check" onclick="$('#exampleCheck2').removeAttr('checked');">
              <input  type="checkbox" class="form-check-input" id="exampleCheck1" name='imports'>
              <label class="form-check-label" for="exampleCheck1">IMPORTS ...</label>
            </div>
            <div class="form-check" onclick="$('#exampleCheck1').removeAttr('checked');">
              <input type="checkbox" class="form-check-input" id="exampleCheck2" name='exports'>
              <label class="form-check-label" for="exampleCheck2">EXPORTS ...</label>
            </div>
				  	
                      <button type="submit" class="btn btn-primary btn-style">
                      modification  de l'archive
                  </button>

              </div>
              

			</form>

            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->

    <?php
             if(isset($_POST['title']) and !empty($_POST['title']) and isset($_FILES['files']) and !empty($_FILES['files'])){
              
              $a=0;
              foreach($get_all_doc as $key=>$value){
                $get_array= strcmp(strtolower(preg_replace("/\s+/", "", $value['title'])),strtolower(preg_replace("/\s+/", "", $_POST['title'])));
                if($get_array == 0){
                    $a = 1;
                }
                
              }

              if($a==0){
                if(!isset($_POST['imports']) and !isset($_POST['exports']) ){
                  ?>
                  <script>
                  alert('selectionne un departement');
                  </script>
                <?php
                }else{
                  $uploads = $get_class->Upload_file($_FILES);
                  if(isset($_POST['imports'])){
                    $departement = 'imports';
                  }
                  if(isset($_POST['exports'])){
                    $departement = 'exports';
                  }
                  if(strcmp('uploads/',$uploads) != 0){

                    
  
                  $title = $_POST['title'];
                  $license_number = $_POST['license_number'];
                  $holder = $_POST['holder'];
                  $issue_date = $_POST['issue_date'];
                  $created_at = $_POST['created_at'];
                  $expire_dat = $_POST['expire_dat'];
                  $id_client = $_GET['id'];
                  $upload_file = $uploads;
                  
                  $insert_archive=$get_class->update_doc($_GET['doc'],$title,$license_number,$holder,$issue_date,$created_at,$expire_dat,$id_client,$upload_file,$departement);
                  ?>
                  <script>
                  alert("modification effectuer");
                  </script>

                  }else{
                    ?>
                    <script>
                    alert("l'installation du fichier n'a pas bien aboutie");
                    </script>
                  <?php
                  }
  
  
                }
                
              }else{
                ?>
                  <script>
                  alert('le fichier existe deja');
                  </script>
                <?php
              }

            

             
             }
            
             
            

              ?>