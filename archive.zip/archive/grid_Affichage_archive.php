
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
            FICHE  D'ARCHIVE
            </div>
            <div class="card-body">
             
            <iframe frameborder="0" height="600" width="100%" scrolling="yes" src="<?php echo $_GET['doc']; ?>"></iframe>

            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->
