
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
            FICHE D’ENREGISTREMENT DES CLIENTS
            </div>
            <div class="card-body">
              <?php
               

                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                
              ?>



<div id='e'></div>
            <form method='post' action='#e'>
			  <div class="col-md-5" style="float: left;">
				  	<div class="form-group">
					    <label for="inputsm">NOM DU CLIENT :</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='nom_client' >
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">NIF DU CLIENT</label>
					    <input class="form-control" id="inputdefault" type="text" name='nif' >
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">NUMERO DE PLAQUE </label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='plaque' >
				  	</div>
				  	<div class="form-group">
					    <label for="inputdefault">MANIFEST</label>
					    <input class="form-control" id="inputdefault" type="text" name='manifest' >
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">TER 8</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='ter' >
				  	</div>
			  </div>

			  <div class="col-md-5" style="float: right;">
				  	<div class="form-group">
					    <label for="inputsm">T1</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='t' >
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">DECLARATION IM4  , IM5 , IM7 :</label>
					    <input class="form-control" id="inputdefault" type="text" name='declaration' >
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">LIQUIDATION (BAE)</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='liquidation'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputdefault">QUITTANCE</label>
					    <input class="form-control" id="inputdefault" type="text" name='quittance'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">BON DE SORTIE</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='sortie' >
                      </div>

                      <button type="submit" class="btn btn-primary btn-style">
                      enregistrement du client
                  </button>

              </div>
              

			</form>







            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->

    

<div id="ke"></div>


<script>
 function Affiche_detail_client(id) {
        $.post('Modal_Aff_client.php',
            {id: id},
            function(data){
                $('#ke').html(data);

            }

        );

    }
</script>

<?php

if(isset($_POST['nom_client'])){
    

$nom_client = $_POST['nom_client'];
$nif = $_POST['nif'];
$plaque = $_POST['plaque'];
$manifest = $_POST['manifest'];
$ter = $_POST['ter'];
$t = $_POST['t'];
$declaration = $_POST['declaration'];
$liquidation = $_POST['liquidation'];
$quittance = $_POST['quittance'];
$sortie = $_POST['sortie'];
$get_array = array();
$get_test = 0;
$test = $get_class->Select_All_Clients();
foreach($test as $key=>$value){
    $get_array= explode(strtolower($value['nom_client']),strtolower($_POST['nom_client']));
    if(count($get_array)==1){
        $get_test = 1;
    }
}

if($get_test !=1){
    
$insert_client = $get_class->Insert_Client($nom_client,$nif,$plaque,$manifest,$ter,$t,$declaration,$liquidation,$quittance,$sortie);
if($insert_client == true){
    ?>
    
        
        <script>
            alert("l'enregistrement du client a ete faite");
            
                document.location.href = 'dashboard.php?cle=3';
        </script>
    <?php
    $insert_client =null;
    
}

}else{
    ?>
    
        
    <script>
        alert("le client existe");
        document.location.href = 'dashboard.php?cle=3';
    </script>
<?php
}
}
?>