
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
            FICHE DE MODIFICATION DE L'UTILISATEUR
            </div>
            <div class="card-body">
              <?php
               

               if(!isset($_SESSION)){
                session_start();
            }
                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                
              ?>



<div id='a'></div>
            <form method='post' action='#a'>
			  <div class="col-md-5" style="float: left;">
				  	<div class="form-group">
					    <label for="inputsm">NOM DU PROFILE DE L'UTILISATEUR</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='nom' >
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">NOM D'UTILISATEUR</label>
					    <input class="form-control" id="inputdefault" type="text" name='username' >
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">MOT DE PASSE </label>
					    <input class="form-control input-lg" id="inputlg" type="password" name='password' >
                      </div>
                      <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-style">
                            MODIFIER L'UTILISATEUR
                        </button>
                      </div>

			  </div>
                <div class="col-md-5" style="float: right;">
                    <?php echo "NOM DU PROFILE DE L'UTILISATEUR COURANT : ".strtoupper($_SESSION['user'][0]['nom']);?><br><br><br>
                    <?php echo "NOM DE L'UTILISATEUR COURANT : ".($_SESSION['user'][0]['username']);?><br><br><br>
                    <?php echo "MOT DE PASSE DE PROFILE DE L'UTILISATEUR COURANT : ".($_SESSION['user'][0]['password']);?>
                </div>
			 
              

			</form>







            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->

    <?php


            if(isset($_SESSION['user'][0]['id']) and isset($_POST['nom'])){
                $id = $_SESSION['user'][0]['id'];
                $nom = $_POST['nom'];
                $username = $_POST['username'];
                $password = $_POST['password'];
             $modif=$get_class->Update_User($id,$nom,$username,$password);
             if($modif == true){
                 ?>
                 <script>
                     alert('modification effectuer');
                     document.location.href = 'test.php';
                 </script>

                 <?php
             }
            }
               
               
    
    ?>