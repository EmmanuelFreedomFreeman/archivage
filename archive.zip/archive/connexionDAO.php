<?php

	class Connexion {
		function getConnexion() {
			try {
				$host = 'mysql:host=localhost;dbname=archive';
				$user = 'root';
				$pwd = '';
				$bdd = new PDO($host, $user, $pwd,
				array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			
			} catch(Exception $e) {
				die('Erreur : '.$e->getMessage());
			}
			
			return $bdd;
		}
	
	function Insert_Users($nom,$username,$password){
        $req=$this->getConnexion()->prepare('insert into users(nom,username,password)VALUES(:nom,:username,:password)');
        $r=$req->execute(array(
            'nom'=>$nom,'username'=>$username,'password'=>$password
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
	}
	function Select_Users($username,$password){
        $req=$this->getConnexion()->prepare('select * from users where username=:username and password=:password');
        $req->execute(array(
			'username'=>$username,'password'=>$password
        ));
        return $req->fetchAll();
	}
	
	function Update_User($id,$nom,$username,$password){
        $req=$this->getConnexion()->prepare('update users set nom=:nom,username=:username,password=:password WHERE id=:id');
        $r=$req->execute(array(
            'id'=>$id,'nom'=>$nom,'username'=>$username,'password'=>$password
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
	}

	// 
	function Insert_Client($nom_client,$nif,$plaque,$manifest,$ter,$t,$declaration,$liquidation,$quittance,$sortie){
        $req=$this->getConnexion()->prepare('insert into client(nom_client,nif,plaque,manifest,ter,t,declaration,liquidation,quittance,sortie)VALUES(:nom_client,:nif,:plaque,:manifest,:ter,:t,:declaration,:liquidation,:quittance,:sortie)');
        $r=$req->execute(array(
            'nom_client'=>$nom_client,'nif'=>$nif,'plaque'=>$plaque,'manifest'=>$manifest,'ter'=>$ter,'t'=>$t,'declaration'=>$declaration,'liquidation'=>$liquidation,'quittance'=>$quittance,'sortie'=>$sortie
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
	}
	function Select_Clients($id){
        $req=$this->getConnexion()->prepare('select * from client where id=:id');
        $req->execute(array(
			'id'=>$id
        ));
        return $req->fetchAll();
	}
	function Select_All_Clients(){
        $req=$this->getConnexion()->prepare('select * from client');
        $req->execute(array(
			
        ));
        return $req->fetchAll();
	}
	function Update_Client($id,$nom_client,$nif,$plaque,$manifest,$ter,$t,$declaration,$liquidation,$quittance,$sortie){
        $req=$this->getConnexion()->prepare('update client set nom_client=:nom_client,nif=:nif,plaque=:plaque,manifest=:manifest,ter=:ter,t=:t,declaration=:declaration,liquidation=:liquidation,quittance=:quittance,sortie=:sortie WHERE id=:id');
        $r=$req->execute(array(
            'id'=>$id,'nom_client'=>$nom_client,'nif'=>$nif,'plaque'=>$plaque,'manifest'=>$manifest,'ter'=>$ter,'t'=>$t,'declaration'=>$declaration,'liquidation'=>$liquidation,'quittance'=>$quittance,'sortie'=>$sortie
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
    }
    function Select_All_DocById($id_client){
        $req=$this->getConnexion()->prepare('select * from doc where id_client=:id_client ORDER BY ID DESC');
        $req->execute(array(
			'id_client'=>$id_client
        ));
        return $req->fetchAll();
    }
    function Select_All_DocByIdDoc($id_client){
        $req=$this->getConnexion()->prepare('select * from doc where id=:id_client ORDER BY ID DESC');
        $req->execute(array(
			'id_client'=>$id_client
        ));
        return $req->fetchAll();
    }
    function Select_All_Doc(){
        $req=$this->getConnexion()->prepare('select * from doc ORDER BY ID DESC');
        $req->execute(array(
			
        ));
        return $req->fetchAll();
    }
    function Select_AllDep_Doc($departement){
        $req=$this->getConnexion()->prepare('select * from doc where departement=:departement ORDER BY ID DESC');
        $req->execute(array(
			'departement'=>$departement
        ));
        return $req->fetchAll();
    }
    function Insert_doc($title,$license_number,$holder,$issue_date,$created_at,$expire_dat,$id_client,$upload_file,$departement){
        $req=$this->getConnexion()->prepare('insert into doc (title,license_number,holder,issue_date,created_at,expire_dat,id_client,upload_file,departement) VALUES(:title,:license_number,:holder,:issue_date,:created_at,:expire_dat,:id_client,:upload_file,:departement)');
        $r=$req->execute(array(
            'title'=>$title,'license_number'=>$license_number,'holder'=>$holder,'issue_date'=>$issue_date,'created_at'=>$created_at,'expire_dat'=>$expire_dat,'id_client'=>$id_client,'upload_file'=>$upload_file,'departement'=>$departement
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
    }
    function update_doc($id,$title,$license_number,$holder,$issue_date,$created_at,$expire_dat,$id_client,$upload_file,$departement){
        $req=$this->getConnexion()->prepare('update doc set title=:title,license_number=:license_number,holder=:holder,issue_date=:issue_date,created_at=:created_at,expire_dat=:expire_dat,id_client=:id_client,upload_file=:upload_file,departement=:departement where id=:id');
        $r=$req->execute(array(
            'id'=>$id,'title'=>$title,'license_number'=>$license_number,'holder'=>$holder,'issue_date'=>$issue_date,'created_at'=>$created_at,'expire_dat'=>$expire_dat,'id_client'=>$id_client,'upload_file'=>$upload_file,'departement'=>$departement
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
	}








    
    function Upload_file($tab){
        
       
            $errors = [];
            $path = 'uploads/';
            $extensions = ['jpg', 'jpeg', 'png', 'gif','doc','docx','gz','html','odt','odp','ods','odg','pdf','pps','ppt','xls','xlsx','zip','txt'];
            
            //$all_files = count($tab['files']['tmp_name']);
    
            
            $file_name = $tab['files']['name'];
            $file_tmp = $tab['files']['tmp_name'];
            $file_type = $tab['files']['type'];
            $file_size = $tab['files']['size'];
            $tmp = explode('.', $tab['files']['name']);
            $file_ext = strtolower(end($tmp));
    
            $file = $path . sha1($file_name.":".time ()).'.'.$file_ext;
    
            if (!in_array($file_ext, $extensions)) {
                $errors[] = "l'extention est refuser: :" . $file_name . ' ' . $file_type;
            }
    
            if ($file_size > 2097152) {
                $errors[] = 'le ficher est trop grand: ' . $file_name . ' ' . $file_type;
            }
    
            if (empty($errors)) {
                move_uploaded_file($file_tmp, $file);
                $path = $file;
                return $path;
                
            }else{
                return $path;
            }

        return $path;
        
    }

	





}

?>

