<?php
include_once "grid_header.php";
?>
  <!-- main content start -->
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

  <div class="container">
			<img src="drapeau.jpg" style="max-width: 150px;float: right;">
			<img src="logo1.png" style="max-width: 250px;float: left;">
			<div style="text-align: center;text-decoration: underline;">
				<h1>AFRIBOX</h1>
				<h3>république démocratique du congo</h5>
					<h3>Haut Katanga Lubumbashi</h3>
				
			</div>
    </div>
    
    
  <?php
  if(!isset($_GET['cle'])){
    include_once "grid_liste_client.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==1 ){
    include_once "grid_liste_client.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==2 ){
    include_once "grid_modif_client.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==3 ){
    include_once "grid_ajout_client.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==4 ){
    include_once "grid_archivage.php";
  }
  
  if(isset($_GET['cle']) and $_GET['cle']==5 ){
    include_once "grid_liste_archive.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==6 ){
    include_once "Modal_Aff_client.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==7 ){
    include_once "grid_add_archive.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==8 ){
    include_once "grid_modif_archive.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==9 ){
    include_once "grid_Affichage_archive.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==10 ){
    include_once "grid_Modif_User.php";
  }
  if(isset($_GET['cle']) and $_GET['cle']==11 ){
    include_once "grid_liste_All_archive.php";
  }
  
  
  
  ?>


  </div>
  <!-- //content -->
</div>
<!-- main content end-->
</section>
  <?php
  include_once "grid_footer.php";
  ?>