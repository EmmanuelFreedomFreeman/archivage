


<?php

include_once "connexionDAO.php";
$user =new Connexion();

$t= $user->Select_All_DocById($_POST['id']);
$u = $user->Select_Clients($_POST['id']);
?>

<style>
    thead{
        color:blueviolet
    }
</style>

        <table class="table" style="float:right">
  <thead class="table table-bordered">
  <tr>
    <th scope="col">CLIENT</th>
      <th scope="col">#</th>
      <th scope="col">TITRE</th>
      <th scope="col">NUMÉRO DE LICENCE</th>
      <th scope="col">TITULAIRE</th>

      <th scope="col">DATE D'ÉMISSION</th>
      <th scope="col">CRÉÉ À</th>
      <th scope="col">EXPIRE À</th>
      <th scope="col">DEPARTEMENT</th>
      <th scope="col">TÉLÉVERSER UN FICHIER</th>
      <th scope="col">MODIFIER</th>

    </tr>
  </thead>
  <tbody>
    <tr >
        <td rowspan="0">
        <img src="folder.png" style="max-width: 30%" />
          <h4>NOM DU CLIENT : <?php echo $u[0]['nom_client']?></h4>
        </td>
    </tr>
    <?php
    $i=1;
    foreach($t as $key=>$value){
        if($value['departement'] == $_POST['dep']){
            ?>
        <tr>
        
            
            <td><?php echo $i; ?></td>
            <td><?php echo $value['title']; ?></td>
            <td><?php echo $value['license_number']; ?></td>
            <td><?php echo $value['holder']; ?></td>

            <td><?php echo $value['issue_date']; ?></td>
            <td><?php echo $value['created_at']; ?></td>
            <td><?php echo $value['expire_dat']; ?></td>
            <td><?php echo $value['departement']; ?></td>
            <td><a href="dashboard.php?cle=9&doc=<?php echo $value['upload_file']; ?>"><?php echo $value['upload_file']; ?></a></td>
            <td><a href="dashboard.php?cle=8&id=<?php echo $_POST['id']; ?>&doc=<?php echo $value['id']; ?>" ><ion-button  ion-button>modifier</ion-button></a></td>
        </tr>
        <?php
        }
        $i++;
    }
    
    ?>
   
  </tbody>
</table>



<script>
  function Affiche_ajax_doc(id) {
        $.post('grid_ajax_archive.php',
            {id: <?php echo $_GET['id']; ?>,'dep': id },
            function(data){
                $('#aj').html(data);

            }

        );

    }
</script>