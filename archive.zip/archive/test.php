<?php
if(!isset($_SESSION)){
    session_start();
}
session_destroy();
?>

?>

<script>
    document.location.href = './';
</script>


<?php