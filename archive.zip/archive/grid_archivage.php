
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
              liste des clients deja enregistrer
            </div>
            <div class="card-body">
              

        <div class="search-box" style="margin-bottom: 10px;">
          <form >
            <input oninput='Search_Client_by_nom();' class="form-control" type="text" placeholder="Search" aria-label="Search" id="yy">
            
          </form>
        </div>


        <div id='se'>
        <?php
                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                $client = $get_class->Select_All_Clients();
              ?>
        <table class="table" >
        <thead class="table table-bordered">
    <tr>
    <th scope="col">#</th>
    <th scope="col">NOM DU CLIENT</th>
      <th scope="col">NIF</th>
      <th scope="col">PLAQUE</th>
      <th scope="col">MANIFEST</th>
      <th scope="col">AFFICHAGE DES DETAILS ET MODIFICATION DU CLIENT</th>
      


    </tr>
  </thead>
  <tbody>
    
        

        
    <?php
    $a=0;
    $i=1;
    foreach($client as $key=>$value){
        ?>
        <tr>
        
            
            <td><?php echo $i; ?></td>
            <td><?php echo $value['nom_client']; ?></td>
            <td><?php echo $value['nif']; ?></td>
            <td><?php echo $value['plaque']; ?></td>
            <td><?php echo $value['manifest']; ?></td>
            <td>
            <a href='dashboard.php?cle=5&id=<?php echo $value['id']; ?>&ff=0000' class="btn btn-primary btn-style" style='color:white'> archive </a>
            <a href='dashboard.php?cle=7&id=<?php echo $value['id']; ?>&ff=0000' class="btn btn-primary btn-style" style='color:white'> archiver </a>
        
        
            </td>
            
            

            
        </tr>
        <?php
        $i++;
    }
    
    ?>
   

        

  </tbody>
</table>
</div>

            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->


<div id="ke"></div>


<script>
 function Affiche_detail_client(id) {
        $.post('Modal_Aff_client.php',
            {id: id},
            function(data){
                $('#ke').html(data);

            }

        );

    }
    function Search_Client_by_nom() {
        var nom = $('#yy').val();
        $.post('grid_search_client.php',
            {nom : nom},
            function(data){
                $('#se').html(data);

            }

        );
        console.log(nom);

    }
</script>

