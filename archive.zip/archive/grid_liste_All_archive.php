
	
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
              LISTE DES ARCHIVES DEJA ENREGISTRER
            </div>
            <div class="card-body">

            
<div id='aj'>          
<?php

include_once "connexionDAO.php";
$user =new Connexion();


if(isset($_GET['dep'])){

  $departement = $_GET['dep'];
  $t = $user->Select_AllDep_Doc($departement);
}else{
  $t= $user->Select_All_Doc();

}

?>

<a href='dashboard.php?cle=11&dep=imports' class="btn btn-info" style='color:white'>imports</a>
<a href="dashboard.php?cle=11&dep=exports" class="btn btn-info" style='color:white'>exports</a>

        <table class="table" style="float:right">
  <thead class="table table-bordered">
    <tr>
    <th scope="col">LISTE DES ARCHIVES DEJA ENREGISTRER</th>
      <th scope="col">#</th>
      <th scope="col">TITRE</th>
      <th scope="col">NUMÉRO DE LICENCE</th>
      <th scope="col">TITULAIRE</th>

      <th scope="col">DATE D'ÉMISSION</th>
      <th scope="col">CRÉÉ À</th>
      <th scope="col">EXPIRE À</th>
      <th scope="col">DEPARTEMENT</th>
      <th scope="col">TÉLÉVERSER UN FICHIER</th>
    </tr>
  </thead>
  <tbody>
    <tr >
        <td rowspan="0">
        <img src="folder.png" style="max-width: 30%" />
          <h4>LISTE DES TOUT LES ARCHIVE</h4>
        </td>
    </tr>
    <?php
    $i=1;
    foreach($t as $key=>$value){
        ?>
        <tr>
        
            
            <td><?php echo $i; ?></td>
            <td><?php echo $value['title']; ?></td>
            <td><?php echo $value['license_number']; ?></td>
            <td><?php echo $value['holder']; ?></td>

            <td><?php echo $value['issue_date']; ?></td>
            <td><?php echo $value['created_at']; ?></td>
            <td><?php echo $value['expire_dat']; ?></td>
            <td><?php echo $value['departement']; ?></td>
            <td><a href="dashboard.php?cle=9&doc=<?php echo $value['upload_file']; ?>"><?php echo $value['upload_file']; ?></a></td>
           
        </tr>
        <?php
        $i++;
    }
    
    ?>
   
  </tbody>
</table>


            </div>


</div>
              
              </div>
            </div>
            <!-- //accordion style 1 -->
          </div>
        </div>
        <!-- //accordions -->

