

        <div id='se'>
        <?php
                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                $client = $get_class->Select_All_Clients();
                
              ?>
        <table class="table" >
  <thead class="thead-dark">
    <tr>
    <th scope="col">#</th>
    <th scope="col">nom_client</th>
      <th scope="col">nif</th>
      <th scope="col">plaque</th>
      <th scope="col">manifest</th>
      <th scope="col">Affichage des details et modification du client</th>
      


    </tr>
  </thead>
  <tbody>
    
        

        
    <?php
    $a=0;
    $i=1;
    $nom=array();
    foreach($client as $key=>$value){

        if(isset($_POST['nom']) and !empty($_POST['nom'])){
            $nom=explode($_POST['nom'],$value['nom_client']);
            if(count($nom)>1){

                ?>
                <tr>
                
                    
                    <td><?php echo $i; ?></td>
                    <td><?php echo $value['nom_client']; ?></td>
                    <td><?php echo $value['nif']; ?></td>
                    <td><?php echo $value['plaque']; ?></td>
                    <td><?php echo $value['manifest']; ?></td>
                    <td>
                        <button type="button" class="btn btn-primary btn-style" data-toggle="modal" 
                            data-target="#exampleModalCenter<?php echo $value['id']; ?>" onclick= "Affiche_detail_client(<?php echo $value['id']; ?>);">
                            details
                          </button>
                          <a href='dashboard.php?cle=2&id=<?php echo $value['id']; ?>' class="btn btn-primary btn-style" style='color:white'> modifier </a>
                
                
                    </td>
                    
                    
        
                    
                </tr>
                <?php
                $i++;

            }
        }
       
    }
    
    
    ?>
   

        

  </tbody>
</table>
</div>

