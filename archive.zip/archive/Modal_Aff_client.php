
            <?php
                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                $client = $get_class->Select_Clients($_GET['id']);
                
            ?>
      
<!-- accordions -->
<div class="accordions">
  <div class="row">
    <!-- accordion style 1 -->
    <div class="col-lg-12 mb-4">
      <div class="card card_border">
        <div class="card-header chart-grid__header">
          AFFICHAGE DU CLIENT DETAILLER
        </div>
        <div class="card-body">
          

 
            <div class="modal-body">
            <img src="client.png" style="float:right"/>
              <h4>NOM DU CLIENT : <?php echo $client[0]['nom_client'];?></h4>
              <h4>NIF DU CLIENT : <?php echo $client[0]['nif'];?></h4>
              <h4>NUMERO DE PLAQUE : <?php echo $client[0]['plaque'];?></h4>
              <h4>MANIFEST : <?php echo $client[0]['manifest'];?></h4>
              <h4>TER 8 : <?php echo $client[0]['ter'];?></h4>
              <h4>T1 : <?php echo $client[0]['t'];?></h4>
              <h4>DECLARATION : IM4, IM5, IM7 : <?php echo $client[0]['declaration'];?></h4>
              <h4>LIQUIDATION (BAE): <?php echo $client[0]['liquidation'];?></h4>
              <h4>QUITTANCE : <?php echo $client[0]['quittance'];?></h4>
              <h4>BON DE SORTIE : <?php echo $client[0]['sortie'];?></h4>
              <h4>NIF DU CLIENT : <?php echo $client[0]['nif'];?></h4>
            </div>
           
</div>

        </div>
          
      </div>
    </div>
    <!-- //accordion style 1 -->
  </div>
</div>
<!-- //accordions -->

