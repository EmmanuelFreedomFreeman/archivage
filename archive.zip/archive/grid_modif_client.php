
    <!-- accordions -->
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
              MODIFICATION DU CLIENT DEJA ENREGISTRER
            </div>
            <div class="card-body">
              <?php
               

                include_once 'connexionDAO.php';
                $get_class = new Connexion();
                $client = $get_class->Select_Clients($_GET['id']);
              ?>



<div id='e'></div>
            <form method='post' action='#e'>
			  <div class="col-md-5" style="float: left;">
				  	<div class="form-group">
					    <label for="inputsm">NOM DU CLIENT :</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='nom_client' value='<?php echo $client[0]['nom_client']?>'>
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">NIF DU CLIENT</label>
					    <input class="form-control" id="inputdefault" type="text" name='nif' value='<?php echo $client[0]['nif']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">NUMERO DE PLAQUE </label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='plaque' value='<?php echo $client[0]['plaque']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputdefault">MANIFEST</label>
					    <input class="form-control" id="inputdefault" type="text" name='manifest' value='<?php echo $client[0]['manifest']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">TER 8</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='ter' value='<?php echo $client[0]['ter']?>'>
				  	</div>
			  </div>

			  <div class="col-md-5" style="float: right;">
				  	<div class="form-group">
					    <label for="inputsm">T1</label>
					    <input class="form-control input-sm" id="inputsm" type="text" name='t' value='<?php echo $client[0]['t']?>'>
				  	</div>
				    <div class="form-group">
					    <label for="inputdefault">DECLARATION IM4  , IM5 , IM7 :</label>
					    <input class="form-control" id="inputdefault" type="text" name='declaration' value='<?php echo $client[0]['declaration']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">LIQUIDATION (BAE)</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='liquidation' value='<?php echo $client[0]['liquidation']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputdefault">QUITTANCE</label>
					    <input class="form-control" id="inputdefault" type="text" name='quittance' value='<?php echo $client[0]['quittance']?>'>
				  	</div>
				  	<div class="form-group">
					    <label for="inputlg">BON DE SORTIE</label>
					    <input class="form-control input-lg" id="inputlg" type="text" name='sortie' value='<?php echo $client[0]['sortie']?>'>
                      </div>

                      <button type="submit" class="btn btn-primary btn-style">
                    modifier
                  </button>

              </div>
              

			</form>







            </div>
              
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->

    

<div id="ke"></div>


<script>
 function Affiche_detail_client(id) {
        $.post('Modal_Aff_client.php',
            {id: id},
            function(data){
                $('#ke').html(data);

            }

        );

    }
</script>

<?php

if(isset($_POST['nom_client'])){
    
$id = $_GET['id'];
$nom_client = $_POST['nom_client'];
$nif = $_POST['nif'];
$plaque = $_POST['plaque'];
$manifest = $_POST['manifest'];
$ter = $_POST['ter'];
$t = $_POST['t'];
$declaration = $_POST['declaration'];
$liquidation = $_POST['liquidation'];
$quittance = $_POST['quittance'];
$sortie = $_POST['sortie'];

$update_client = $get_class->Update_Client($id,$nom_client,$nif,$plaque,$manifest,$ter,$t,$declaration,$liquidation,$quittance,$sortie);

if($update_client == true){
    ?>
    
        
        <script>
            alert('la modification du client a ete faite');
            
                document.location.href = 'dashboard.php?cle=2&id=<?php echo $_GET['id']; ?>&motif=la modification du client a ete faite';
        </script>
    <?php
    $update_client =null;
    
}
}

?>